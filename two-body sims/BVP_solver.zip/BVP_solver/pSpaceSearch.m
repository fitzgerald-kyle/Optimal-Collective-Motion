function p0Vec= pSpaceSearch(x0, x1, numPts, dim1, dim2, dim3)
    params= parameters(200);
    p0Vec= zeros(numPts,6);
    for i= 1:numPts
        % solve IVP for random p0 in prism defined by intervals [-dim1 dim1], 
        % [-dim2 dim2], [-dim3 dim3]
        p0= [2*dim1*rand-dim1, 2*dim2*rand-dim2, 2*dim3*rand-dim3, ...
            2*dim1*rand-dim1, 2*dim2*rand-dim2, 2*dim3*rand-dim3];
        p0Vec(i,:)= p0;
        
        lastErr= inf;
        output= solve_IVP(x0,p0,1,params,0);
        err= output.x(end,:)-x1;
        lastx= output.x(end,:);
        iter= 1; mu= 1; dMu= 1;
        while norm(err) > params.tol && iter <= params.nmax
            output= solve_IVP(x0,p0,1,params,mu);
            lastErr= err;
            err= output.x(end,:)-x1;
            
            % solve 
            muJacobian= (output.x(end,:)-lastx) / dMu;
            dMu= -muJacobian' \ err';
            %dMu= .1;
            if dMu > 5
                mu= mu+5;
            else
                mu= mu+dMu;
            end
            lastx= output.x(end,:);
            fprintf('iteration %i: error %.6f\n', iter, norm(err));
            iter= iter+1;
        end
    end
end

% change solveBVP to have dMu instead of dp0;
% plot a 3D graph of p01-p02-p03 with different colors for different
% numbers of non-optimal solutions (multiple for different p04-p05-p06);
% spreadsheet of solutions?;
% round p0 to hundredth then calculate?