function output = trajectory_search(direction, search_start, search_angle, search_radius, search_time, x0, xf, tf, params)
    %{
        Searches a section of a sphere with point at search_start and center axis pointing in the given
        direction in p-space, sampling random points.

        Inputs:
            direction       - search trajectory (p0 + mu tacked on the end)
    %}
    
    % Convert direction to spherical coordinates
    dir_angles = zeros(1,6);
    dir_angles(1) = acot(direction(1) / norm(direction(2:end)));
    dir_angles(2) = acot(direction(2) / norm(direction(3:end)));
    dir_angles(3) = acot(direction(3) / norm(direction(4:end)));
    dir_angles(4) = acot(direction(4) / norm(direction(5:end)));
    dir_angles(5) = acot(direction(5) / norm(direction(6:end)));
    dir_angles(6) = 2 * acot((direction(6) + norm(direction(6:end))) / norm(direction(7)));

     % Start timer
    end_time = cputime + search_time;

    to_write = '';

    output = zeros(0,7);
    to_write = {};
    % Sample points until we run out of time
    while cputime < end_time
        % Get random spherical coordinates in cone centered around the given direction
        angles = rand(1,6) .* (2 * search_angle) - search_angle + dir_angles;
        angles = mod(abs(angles), pi);
        r = rand * search_radius;

        % Convert from spherical to Cartesian coordinates
        sample = zeros(1,7);
        sample(1) = r * cos(angles(1));
        sample(2) = r * sin(angles(1)) * cos(angles(2));
        sample(3) = r * sin(angles(1)) * sin(angles(2)) * cos(angles(3));
        sample(4) = r * sin(angles(1)) * sin(angles(2)) * sin(angles(3)) * cos(angles(4));
        sample(5) = r * sin(angles(1)) * sin(angles(2)) * sin(angles(3)) * sin(angles(4)) * cos(angles(5));
        sample(6) = r * sin(angles(1)) * sin(angles(2)) * sin(angles(3)) * sin(angles(4)) * sin(angles(5)) * cos(angles(6));
        sample(7) = r * sin(angles(1)) * sin(angles(2)) * sin(angles(3)) * sin(angles(4)) * sin(angles(5)) * sin(angles(6));

        sample = sample + search_start; % Translate cone of search over to search_start

        % Solve the BVP problem for the sampled point
        params.mu = sample(1); % Mu is the first dimension of the space
        p0 = sample(2:7); % The rest are defined by p

        fprintf('Solving BVP for parameters mu = %f p0 = [ ', params.mu); fprintf('%f ', p0); fprintf(']\n');
        try 
            output_bvp = solve_BVP(x0, p0, xf, tf, params);
            output(end+1,:) = [params.mu output_bvp.p0(end,:)];

            % Store csv printout
            out_str = log_bvp_solution(1, output_bvp, params);
            to_write(end+1) = {out_str(1:end-2)};
        catch exception
            warning('BVP solver failed!');
            fprintf(2, '%s\n', exception.message);
            warning('Continuing...');
        end
    end

    % Write output to csv
    out_file = sprintf('trajectory=%d %d %d %d %d %d %d search_start=%d %d %d %d %d %d %d.csv',...
                        floor(direction), floor(search_start));
    fprintf('Writing results to %s...', out_file);
    fd = fopen([params.csv_outdir,'/',out_file], 'w'); % Get file descriptor
    fprintf(fd, '%s\n', to_write{:});
    fclose(fd);

    fprintf('done!\n');

end