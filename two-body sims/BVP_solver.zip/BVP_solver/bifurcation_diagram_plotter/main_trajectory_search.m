function main_trajectory_search

    % End of time interval
    tf = 1;

    % Initial condition for x(0)
    x0 = [0 0 0 0 0 0];
    xf = [0.5 0 0 0.5 0 0];

    % Structure containing parameters (see parameters function below)
    params = parameters; 
    params.draw_path = 0;
    params.draw_jacobian = 0;
    params.nmax = 100;

    search_angle = pi / 75;
    search_radius = 4;
    search_time = 3 * 60;

    search_start = [0.011494	64.275913	-0.002092	1.128088	-54.31778	0.00061	10.072148];
    trajectory = search_start - [0	62.727601	-0.00149	1.202291	-53.273941	0.00051	9.944024];
    trajectory = trajectory / norm(trajectory);


    solution_p0 = trajectory_search(trajectory, search_start, search_angle, search_radius, search_time, x0, xf, tf, params);

    % Plot outputs
    scatter3(solution_p0(:,2), solution_p0(:,3), solution_p0(:,4), 0.5, solution_p0(:,1));
    colormap(copper);
    xlabel('p0_1');
    ylabel('p0_2');
    zlabel('p0_3');
    colorbar;

end